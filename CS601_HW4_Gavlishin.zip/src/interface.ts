// interface for country class
export interface ICountry{
    name: string;
    getInfo(item: HTMLElement): HTMLElement;

}